/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package basicgraphics;

import java.awt.Graphics;

/**
 *
 * @author steve
 */
public interface PaintRegion {
    public void paintRegion(Graphics g,int sx1,int sy1,int sx2,int sy2,int dx1,int dy1,int dx2,int dy2);
}
