/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package basicgraphics.images;

import java.awt.Dimension;
import java.awt.Graphics;

/**
 *
 * @author steve
 */
public interface Painter {
    public void paint(Graphics g,Dimension d);
}
