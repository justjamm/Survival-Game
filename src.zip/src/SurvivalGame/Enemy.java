package SurvivalGame;

import basicgraphics.Scene;
import basicgraphics.Sprite;

public class Enemy extends Sprite {

    public Enemy(Scene scene) {
        super(scene);
    }
}
